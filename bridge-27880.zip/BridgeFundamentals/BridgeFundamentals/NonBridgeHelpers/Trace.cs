﻿
namespace Sodes.Base
{
	//public abstract class Trace
	//{
	//  public abstract void WriteLine(string line);

	//  public static Trace Instance { get; protected set; }
	//}
}
